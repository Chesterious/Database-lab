/**
 * index_iterator.cpp
 */
#include <cassert>

#include "storage/index/index_iterator.h"

namespace bustub {

/*
 * NOTE: you can change the destructor/constructor method here
 * set your own input parameters
 */
INDEX_TEMPLATE_ARGUMENTS
INDEXITERATOR_TYPE::IndexIterator() = default;

INDEX_TEMPLATE_ARGUMENTS
INDEXITERATOR_TYPE::IndexIterator(BufferPoolManager *bpm, B_PLUS_TREE_LEAF_PAGE_TYPE *leaf_page, int index)
    : leaf_page_(leaf_page), index_(index), buffer_pool_manager_(bpm), current_page_id_(INVALID_PAGE_ID), is_end_(true) {

  if(leaf_page_ != nullptr) {
    current_page_id_ = leaf_page_->GetPageId();//设置当前页面ID
    
    //检查索引是否在有效范围内
    if (index_ >= 0 && index_ < leaf_page_->GetSize()) {
      is_end_ = false;  // 有效位置
    } else if (index_ == leaf_page_->GetSize()) {
      //索引刚好达到当前页面的边上，检查是否有下一页
      page_id_t next_page_id = leaf_page_->GetNextPageId();
      if (next_page_id != INVALID_PAGE_ID) {
        //有下一页，需要加载下一页并将索引重置为0
        //这里可以先标记为结束，在operator++中处理页面切换
        is_end_ = false;
      } else {
        is_end_ = true;  //没有下一页，确实是结束
      }
    } else{
        //既不在叶子里，也不在叶子边上，那么索引无效
        is_end_ = true;
    }
  }
}

INDEX_TEMPLATE_ARGUMENTS
INDEXITERATOR_TYPE::~IndexIterator() {
  //在析构时取消固定当前页面
  if (current_page_id_ != INVALID_PAGE_ID && buffer_pool_manager_ != nullptr) {
    buffer_pool_manager_->UnpinPage(current_page_id_, false);
  }
}

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::IsEnd() -> bool {
    
    //throw std::runtime_error("unimplemented"); 
    return is_end_;
}

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::operator*() -> const MappingType & { 
    //throw std::runtime_error("unimplemented"); 
    if (IsEnd()) {
        throw std::runtime_error("Iterator is at end");
    }
    return leaf_page_->GetItem(index_);
}

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::operator++() -> INDEXITERATOR_TYPE & { 
    //throw std::runtime_error("unimplemented"); 
    if (IsEnd()) {
      return *this;
    }

    
    if(index_ < leaf_page_->GetSize() - 1){//先检查页内索引
        index_++;
        return *this;
    }
    
    //需要切换到下一页，但是先不急着动current_page_id_
    page_id_t next_page_id = leaf_page_->GetNextPageId();
    if (next_page_id == INVALID_PAGE_ID) {
      //没有下一页，到达末尾
      is_end_ = true;
      return *this;
    }

    //保存当前页面ID用于取消固定
    page_id_t old_page_id = current_page_id_;
    
    //获取下一页
    Page *next_page = buffer_pool_manager_->FetchPage(next_page_id);
    if (next_page == nullptr) {
      is_end_ = true;
      return *this;
    }

    //将旧页面的固定位取消，代表现在迭代器没有在使用它了
    if (old_page_id != INVALID_PAGE_ID) {
      buffer_pool_manager_->UnpinPage(old_page_id, false);
    }

    //更新迭代器状态
    leaf_page_ = reinterpret_cast<B_PLUS_TREE_LEAF_PAGE_TYPE *>(next_page->GetData());//强制转换
    current_page_id_ = next_page_id;//放心赋值给current_page_id_
    index_ = 0;//重置页内索引为0
      
    //检查新页面是否为空
    if (leaf_page_->GetSize() == 0) {
      is_end_ = true;
      // 如果新页面为空，也应该取消固定
      buffer_pool_manager_->UnpinPage(current_page_id_, false);
      current_page_id_ = INVALID_PAGE_ID;
    }
    

    return *this;

}

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::operator==(const IndexIterator &other) const -> bool {
    if (is_end_ && other.is_end_) {
        return true;
    }
    if (is_end_ != other.is_end_) {
        return false;
    }
    return current_page_id_ == other.current_page_id_ && index_ == other.index_;
}

INDEX_TEMPLATE_ARGUMENTS
auto INDEXITERATOR_TYPE::operator!=(const IndexIterator &other) const -> bool {
    return !(*this == other);
}

template class IndexIterator<GenericKey<4>, RID, GenericComparator<4>>;

template class IndexIterator<GenericKey<8>, RID, GenericComparator<8>>;

template class IndexIterator<GenericKey<16>, RID, GenericComparator<16>>;

template class IndexIterator<GenericKey<32>, RID, GenericComparator<32>>;

template class IndexIterator<GenericKey<64>, RID, GenericComparator<64>>;

}  // namespace bustub




