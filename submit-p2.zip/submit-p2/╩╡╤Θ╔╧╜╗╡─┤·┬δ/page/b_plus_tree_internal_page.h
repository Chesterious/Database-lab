#pragma once

#include <queue>

#include "storage/page/b_plus_tree_page.h"

namespace bustub {

#define B_PLUS_TREE_INTERNAL_PAGE_TYPE                                         \
  BPlusTreeInternalPage<KeyType, ValueType, KeyComparator>

/**
 * B+Tree 内部结点页：
 * 存放若干 <KeyType, ValueType> 对，
 * 其中 ValueType 通常为子结点的 page_id_t
 */
template <typename KeyType, typename ValueType, typename KeyComparator>
class BPlusTreeInternalPage : public BPlusTreePage {
public:
  /**
   * 新建内部结点后，必须调用 Init：
   * 设置页号、父页号、页类型以及最大容量
   */
  void Init(page_id_t page_id, page_id_t parent_id = INVALID_PAGE_ID);

  /** 下标访问 / 修改 key 与 value */
  KeyType KeyAt(int index) const;
  void SetKeyAt(int index, const KeyType &key);

  /** 根据 value 查找其在数组中的位置（未找到返回 GetSize） */
  int ValueIndex(const ValueType &value) const;

  ValueType ValueAt(int index) const;
  void SetValueAt(int index, const ValueType &value);

  /** 根据 key 选择合适的子结点 */
  ValueType Lookup(const KeyType &key, const KeyComparator &comparator) const;

  /** 为新根节点填充 old_value 与 <new_key, new_value> */
  void PopulateNewRoot(const ValueType &old_value, const KeyType &new_key,
                       const ValueType &new_value);

  /** 在 value == old_value 的项之后插入 <new_key, new_value> */
  int InsertNodeAfter(const ValueType &old_value, const KeyType &new_key,
                      const ValueType &new_value);

  /** 删除与 size 调整相关接口 */
  void Remove(int index);
  ValueType RemoveAndReturnOnlyChild();

  /** 分裂 / 合并 / 重分配时使用的移动函数 */
  void MoveHalfTo(BPlusTreeInternalPage *recipient,
                  BufferPoolManager *buffer_pool_manager);

  void MoveAllTo(BPlusTreeInternalPage *recipient, int index_in_parent,
                 BufferPoolManager *buffer_pool_manager);

  void MoveFirstToEndOf(BPlusTreeInternalPage *recipient,
                        BufferPoolManager *buffer_pool_manager);

  void MoveLastToFrontOf(BPlusTreeInternalPage *recipient,
                         int parent_index,
                         BufferPoolManager *buffer_pool_manager);

  /** 调试与打印相关工具 */
  std::string ToString(bool verbose) const;

  void QueueUpChildren(std::queue<BPlusTreePage *> *queue,
                       BufferPoolManager *buffer_pool_manager);

private:
  /** 内部使用的拷贝函数（配合分裂 / 合并 / 重分配） */
  void CopyHalfFrom(MappingType *items, int size,
                    BufferPoolManager *buffer_pool_manager);

  void CopyAllFrom(MappingType *items, int size,
                   BufferPoolManager *buffer_pool_manager);

  void CopyLastFrom(const MappingType &pair,
                    BufferPoolManager *buffer_pool_manager);

  void CopyFirstFrom(const MappingType &pair, int parent_index,
                     BufferPoolManager *buffer_pool_manager);

  MappingType array[0];  // 实际存放 <key, child_page_id> 的数组区域
};

} // namespace bustub
