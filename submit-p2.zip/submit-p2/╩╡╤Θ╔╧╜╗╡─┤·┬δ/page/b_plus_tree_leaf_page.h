#pragma once

#include <utility>
#include <vector>

#include "storage/page/b_plus_tree_page.h"

namespace bustub {

#define B_PLUS_TREE_LEAF_PAGE_TYPE                                             \
  BPlusTreeLeafPage<KeyType, ValueType, KeyComparator>

/**
 * B+Tree 叶子结点页：
 * 存放有序的 <KeyType, ValueType> 映射以及链表指针 next_page_id_
 */
template <typename KeyType, typename ValueType, typename KeyComparator>
class BPlusTreeLeafPage : public BPlusTreePage {
public:
  /**
   * 新页从缓冲池拿出来后，需要显式调用 Init 进行初始化：
   * 设置页类型、父子关系、容量等
   */
  void Init(page_id_t page_id, page_id_t parent_id = INVALID_PAGE_ID);

  /** 与叶子链表相关的辅助接口 */
  page_id_t GetNextPageId() const;
  void SetNextPageId(page_id_t next_page_id);

  /** 以下标访问对应 key（只读） */
  KeyType KeyAt(int index) const;

  void SetKeyAt(int index, const KeyType &key);
  void SetValueAt(int index, const ValueType &value);
  ValueType ValueAt(int index) const;



  
  /**
   * 返回第一个满足 array[i].first >= key 的下标，
   * 常用于迭代器起始位置
   */
  int KeyIndex(const KeyType &key, const KeyComparator &comparator) const;

  /** 获取指定下标处的 <key, value> 对 */
  const MappingType &GetItem(int index);

  /** 插入 / 查找 / 删除接口 */
  int Insert(const KeyType &key, const ValueType &value,
             const KeyComparator &comparator);

  bool Lookup(const KeyType &key, ValueType &value,
              const KeyComparator &comparator) const;

  int RemoveAndDeleteRecord(const KeyType &key,
                            const KeyComparator &comparator);

  /** 分裂与合并时使用的移动工具函数 */
  void MoveHalfTo(BPlusTreeLeafPage *recipient,
                  BufferPoolManager *buffer_pool_manager /* Unused */);

  void MoveAllTo(BPlusTreeLeafPage *recipient, int /* Unused */,
                 BufferPoolManager * /* Unused */);

  void MoveFirstToEndOf(BPlusTreeLeafPage *recipient,
                        BufferPoolManager *buffer_pool_manager);

  void MoveLastToFrontOf(BPlusTreeLeafPage *recipient, int parentIndex,
                         BufferPoolManager *buffer_pool_manager);

  /** 调试输出：打印页内容 */
  std::string ToString(bool verbose = false) const;

private:
  /** 以下为内部辅助拷贝函数，仅在分裂、合并、重分配时调用 */
  void CopyHalfFrom(MappingType *items, int size);
  void CopyAllFrom(MappingType *items, int size);
  void CopyLastFrom(const MappingType &item);
  void CopyFirstFrom(const MappingType &item, int parentIndex,
                     BufferPoolManager *buffer_pool_manager);

  page_id_t next_page_id_;  // 叶子链表中后继页页号
  MappingType array[0];     // 实际存放 <key, value> 的可扩展数组区域
};

} // namespace bustub
